# Linear direct and adjoint simulation of 2D differentially heated square cavity.

This is small 2D example of the linear direct and adjoint simulation
of differentially heated square cavity. The linear stability of natural
convection is tested and the grow rate of one of the modes is compared
with the result of the linear stability analysis.
This simulation tests temperature adjoint.