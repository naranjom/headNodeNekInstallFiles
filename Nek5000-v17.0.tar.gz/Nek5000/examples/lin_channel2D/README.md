# Linear direct and adjoint simulation of 2D Poiseuille flow.

This is small 2D example of the linear direct and adjoint simulation
of 2D Poiseuille flow, in which a fluid is moving laterally between
two plates whose length and width is much greater than the distance
separating them. Stability of this 2D parallel flow can be investigated
analitcally by local analysis and we compare growth rate of the strongest
mode with the stability calculation.
