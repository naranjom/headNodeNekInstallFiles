# Vortex breakdown in a container with a rotating lid.

For more information see pdf file.