# Mesh smoothing in Nek5000.

For more information see pdf file